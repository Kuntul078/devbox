#!/usr/bin/python3
"""
SafelinkU Bypass Bot - Telegram control panel.

Kirim link -> pilih country + jumlah view (manual / preset) -> antrian -> worker
menjalankan setiap view dengan device profile + IP residential baru.

state.json (ditulis panel):
  {"link": "...", "country": "us", "pending_views": 5, "mode": null}
queue.txt  (dibaca worker): satu JSON job per baris
"""
import os, sys, json, time, logging, subprocess
from pathlib import Path
import requests
from requests.adapters import HTTPAdapter
try:
    from urllib3.util.retry import Retry
except Exception:          # urllib3 v1 fallback
    Retry = None

HERE = os.path.dirname(os.path.abspath(__file__))
QUEUE = os.path.join(HERE, "queue.txt")
RESULTS = os.path.join(HERE, "results.txt")
ARCHIVE = os.path.join(HERE, "results_archive.txt")
STATE = os.path.join(HERE, "state.json")
OFFSET_FILE = os.path.join(HERE, ".offset")
LOCK_FILE = os.path.join(HERE, "panel.lock")
HB = "/home/ubuntu/workspace/projects/safelink-bot/.bot-heartbeat/safelink-bot.hb"
LOGDIR = os.path.join(HERE, "logs")
os.makedirs(LOGDIR, exist_ok=True)
os.makedirs(os.path.dirname(HB), exist_ok=True)

sys.path.insert(0, HERE)
from fp_spoof import COUNTRIES
import proxy_setup

PROXY_CMD = "/proxy"

logging.basicConfig(
    level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s",
    handlers=[logging.FileHandler(os.path.join(LOGDIR, "panel.log")),
              logging.StreamHandler(sys.stdout)])

ENV = {}
OFFSET = None
API = None
ALLOWED_CHAT = None
VIEW_PRESETS = [1, 5, 10, 25, 50, 100]


# ------------------------------------------------------------------ helpers
def load_env():
    for line in open(os.path.join(HERE, ".env")):
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        ENV[k.strip()] = v.strip()
        os.environ[k.strip()] = v.strip()   # overwrite: .env is source of truth


SESSION = None


def make_session():
    """Single pooled Session for every Telegram call.

    Why: `requests.post()` opens a fresh socket every call and does NOT retry.
    Under flaky IPv6 to api.telegram.org a single hung read used to block the
    whole panel for the full read-timeout; with keep-alive we reuse the socket
    and a dead pooled connection is dropped automatically by urllib3's Retry.
    """
    s = requests.Session()
    if Retry is not None:
        rt = Retry(total=3, connect=3, read=2, backoff_factor=0.8,
                   status_forcelist=(429, 500, 502, 503, 504),
                   allowed_methods=frozenset(["GET", "POST"]))
        ad = HTTPAdapter(max_retries=rt, pool_connections=4, pool_maxsize=8)
    else:
        ad = HTTPAdapter(pool_connections=4, pool_maxsize=8)
    s.mount("https://", ad)
    s.mount("http://", ad)
    return s


def api(method, **params):
    global SESSION
    url = f"{API}/{method}"
    if SESSION is None:
        SESSION = make_session()
    last = None
    for attempt in range(3):
        try:
            # NEVER use a 70s read here: a hung read is what made the panel look dead.
            r = SESSION.post(url, json=params, timeout=(6, 25))
            j = r.json()
            if not j.get("ok"):
                logging.warning("api %s -> %s", method, json.dumps(j)[:200])
            return j
        except Exception as e:
            last = e
            logging.warning("api %s attempt %d failed: %s", method, attempt + 1, e)
            # a dead pooled socket must be thrown away, otherwise every retry reuses it
            try:
                SESSION.close()
            except Exception:
                pass
            SESSION = make_session()
            time.sleep(1.5 * (attempt + 1))
    logging.error("api %s gave up: %s", method, last)
    return {}


def load_offset():
    try:
        return int(open(OFFSET_FILE).read().strip())
    except Exception:
        return None


def save_offset(o):
    try:
        with open(OFFSET_FILE, "w") as f:
            f.write(str(int(o)))
    except Exception:
        pass


def acquire_lock():
    """Refuse to run two pollers on one token: the loser would steal updates and
    the panel would look alive while answering nothing."""
    import fcntl
    f = open(LOCK_FILE, "w")
    try:
        fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except Exception:
        logging.error("another panel instance already polls this token -- exiting")
        sys.exit(0)
    return f


def set_commands():
    """Daftarkan menu command di Telegram (tombol biru di kiri kolom chat).

    sendData: BotCommand[] -> kalau gagal (mis. deskripsi invalid) panel TETAP
    lanjut; menu command cuma kemudahan, bukan syarat hidup.
    """
    cmds = [
        {"command": "menu", "description": "Panel utama + status"},
        {"command": "proxy", "description": "Input proxy manual (step-by-step / paste / file)"},
        {"command": "setproxy", "description": "Sama dengan /proxy"},
        {"command": "setcountry", "description": "Ganti country keluar, mis. /setcountry us"},
        {"command": "setviews", "description": "Set jumlah view, mis. /setviews 50"},
        {"command": "cancel", "description": "Batalkan input yang sedang jalan"},
    ]
    try:
        r = api("setMyCommands", commands=cmds)
        logging.info("setMyCommands: %s", "ok" if r.get("ok") else r.get("description"))
    except Exception as e:
        logging.warning("setMyCommands gagal: %s", e)


def read_lines(path):
    if not os.path.exists(path):
        return []
    return [l.strip() for l in open(path) if l.strip()]


def read_jobs():
    out = []
    for ln in read_lines(QUEUE):
        try:
            j = json.loads(ln)
            if isinstance(j, dict) and j.get("url"):
                out.append(j)
        except Exception:
            out.append({"url": ln, "views": 1,
                        "country": ENV.get("PROXY_COUNTRY", "id"), "done": 0})
    return out


def write_jobs(jobs):
    tmp = QUEUE + ".tmp"
    with open(tmp, "w") as f:
        for j in jobs:
            f.write(json.dumps(j, ensure_ascii=False) + "\n")
    os.replace(tmp, QUEUE)


def read_state():
    try:
        return json.load(open(STATE))
    except Exception:
        return {}


def write_state(s):
    with open(STATE, "w") as f:
        json.dump(s or {}, f, ensure_ascii=False)


def clear_mode(st):
    """Drop any pending free-text prompt. Never let a half-finished prompt lock the panel."""
    st.pop("mode", None)
    st.pop("mode_ts", None)
    st.pop("wiz", None)
    return st


def worker_state():
    """The job the worker currently holds (queue empty => it is in-flight)."""
    if read_jobs():
        return {}
    try:
        return json.load(open(STATE))
    except Exception:
        return {}


def results_stats():
    rows = []
    for ln in read_lines(RESULTS):
        try:
            rows.append(json.loads(ln))
        except Exception:
            pass
    return rows, sum(1 for r in rows if r.get("ok"))


def cname(code):
    for c, label in COUNTRIES:
        if c == code:
            return label
    return code.upper()


def proxy_text():
    """Ringkasan status proxy manual (dipakai bareng /proxy)."""
    cfg = proxy_setup.load()
    if not cfg:
        return ("🔌 *Proxy:* ⚠️ belum diset — view jalan lewat IP server, "
                "rawan di-dedupe.\n\n")
    ok = proxy_setup.configured()
    lines = ["🔌 *Proxy (manual BrightData)*\n"]
    lines.append(f"• Host: `{cfg.get('PROXY_HOST')}:{cfg.get('PROXY_PORT')}`")
    lines.append(f"• Country: {cname(cfg.get('PROXY_COUNTRY','id'))}")
    lines.append(f"• User: `{(cfg.get('PROXY_USER') or '')[:58]}`")
    lines.append(f"• Pass: `{(cfg.get('PROXY_PASS') or '')[:2]}***`")
    lines.append(f"• Aktif: {'✅ ya' if ok else '❌ kredensial kosong'}")
    lines.append("")
    lines.append("Tekan tombol di bawah buat input manual (step-by-step / paste / "
                 "ambil dari file).")
    return "\n".join(lines)


def proxy_usage():
    return ("🔌 *Set proxy manual*\n\n"
            "Kirim:\n`/proxy user:pass@host:port`\n"
            "atau\n`/proxy host:port:user:pass`\n\n"
            f"Contoh user (session wajib):\n"
            f"`{proxy_setup.EXAMPLE_USER}`\n\n"
            "`/proxy country id`   — ganti country keluar\n"
            "`/proxy test`         — tes kredensial tersimpan\n"
            "`/proxy off`          — matikan proxy (langsung IP server)\n"
            "`/proxy on`           — aktifkan lagi\n\n"
            "Perubahan langsung kepakai di view berikutnya (tanpa restart).")


# --------------------------------------------------- proxy wizard (manual)
# Tujuan: input proxy manual LANGSUNG di Telegram, step-by-step, tanpa perlu
# ketik satu baris panjang `user:pass@host:port`. Tiap langkah disimpan di
# state.json (mode="wiz", wiz=<langkah>, wiz_data={...}) supaya aman kalau
# panel restart di tengah wizard. Pesan yang berisi password DIHAPUS setelah
# dibaca (kalau bot punya hak delete), lalu password disimpan ke proxy.env 0600.
WIZ_CANCEL = ("/cancel", "/batal", "/x", "batal", "cancel")


def _wiz_cfg_defaults():
    cfg = proxy_setup.load() or {}
    return {
        "PROXY_HOST": cfg.get("PROXY_HOST") or "brd.superproxy.io",
        "PROXY_PORT": cfg.get("PROXY_PORT") or "44445",
        "PROXY_USER": cfg.get("PROXY_USER") or "",
        "PROXY_PASS": cfg.get("PROXY_PASS") or "",
        "PROXY_COUNTRY": cfg.get("PROXY_COUNTRY") or ENV.get("PROXY_COUNTRY", "id"),
        "USE_PROXY": cfg.get("USE_PROXY") or "1",
    }


def _wiz_set(s, step, data=None):
    s["mode"], s["mode_ts"] = "wiz", time.time()
    s["wiz"] = step
    if data is not None:
        s["wiz_data"] = data
    write_state(s)


def _wiz_data(s):
    d = s.get("wiz_data") or {}
    return d if isinstance(d, dict) else {}


def tokenize_line(line):
    """Terima 1 baris panjang ATAU potongan yang dipisah spasi/baris.

    Contoh yang semuanya jalan:
      user:pass@host:port | host:port:user:pass | user:pass@host
      host port user pass | user pass host port | user@host port pass
    -> (cfg, None) or (None, "pesan error")
    """
    toks = (line or "").replace("\n", " ").split()
    if not toks:
        return None, "kosong"

    joined = " ".join(toks)
    if len(toks) == 1:
        c = proxy_setup.parse_line(joined)
        if c:
            return c, None

    parts = list(toks)
    if len(parts) == 4:
        for cfg, label in (
            ({"PROXY_USER": parts[0], "PROXY_PASS": parts[1],
              "PROXY_HOST": parts[2], "PROXY_PORT": parts[3]}, "user pass host port"),
            ({"PROXY_HOST": parts[0], "PROXY_PORT": parts[1],
              "PROXY_USER": parts[2], "PROXY_PASS": parts[3]}, "host port user pass"),
        ):
            if cfg["PROXY_PORT"].isdigit():
                merged = dict(proxy_setup.DEFAULTS)
                merged.update(cfg)
                return proxy_setup.parse_line(
                    f"{merged['PROXY_USER']}:{merged['PROXY_PASS']}"
                    f"@{merged['PROXY_HOST']}:{merged['PROXY_PORT']}"), None

    if len(parts) == 3:
        d2 = _hostport_split(parts[2])
        if d2:
            merged = dict(proxy_setup.DEFAULTS)
            merged.update(PROXY_USER=parts[0], PROXY_PASS=parts[1],
                          PROXY_HOST=d2[0], PROXY_PORT=d2[1])
            return proxy_setup.parse_line(
                f"{merged['PROXY_USER']}:{merged['PROXY_PASS']}"
                f"@{merged['PROXY_HOST']}:{merged['PROXY_PORT']}"), None
        d0 = _hostport_split(parts[0])
        if d0:
            merged = dict(proxy_setup.DEFAULTS)
            merged.update(PROXY_HOST=d0[0], PROXY_PORT=d0[1],
                          PROXY_USER=parts[1], PROXY_PASS=parts[2])
            return proxy_setup.parse_line(
                f"{merged['PROXY_USER']}:{merged['PROXY_PASS']}"
                f"@{merged['PROXY_HOST']}:{merged['PROXY_PORT']}"), None

    d2 = _hostport_split(parts[-1])
    if d2 and len(parts) == 3:
        pass
    if len(parts) >= 2 and d2:
        up = " ".join(parts[:-1])
        if ":" in up:
            u, p = up.split(":", 1)
            return proxy_setup.parse_line(
                f"{u}:{p}@{d2[0]}:{d2[1]}"), None

    return None, "format tidak dikenali"


def _hostport_split(tok):
    """'brd.superproxy.io:44445' -> (host, port) atau None."""
    if not tok or tok.count(":") != 1:
        return None
    h, p = tok.split(":", 1)
    if not h or not p.isdigit():
        return None
    return h.strip(), p.strip()


def _parse_cred_line(line):
    """Terima salah satu: user:pass | user pass | user,pass | user@host:port pass."""
    line = (line or "").strip()
    if not line:
        return None
    if ":" in line and " " not in line:
        u, p = line.split(":", 1)
        return (u.strip(), p.strip()) if u.strip() and p.strip() else None
    if " " in line:
        toks = line.split()
        if len(toks) == 2:
            return (toks[0].strip(), toks[1].strip())
        if len(toks) >= 2 and "@" in toks[0]:
            return (toks[0].strip(), " ".join(toks[1:]).strip())
    if "," in line:
        u, p = line.split(",", 1)
        return (u.strip(), p.strip()) if u.strip() and p.strip() else None
    return None


def wizard_kb(step):
    rows = [[{"text": "🛠 Input manual (step-by-step)", "callback_data": "wiz"}],
            [{"text": "📋 Paste 1 baris (host:port:user:pass)", "callback_data": "paste"}],
            [{"text": "📥 Ambil dari file .env / .txt", "callback_data": "importfrom"}],
            [{"text": "🧪 Tes proxy tersimpan", "callback_data": "proxytest"},
             {"text": "⬅️ Menu", "callback_data": "menu"}]]
    if step:
        rows.insert(0, [{"text": f"📝 Langkah {step}/5 — kirim datanya (atau /cancel)",
                         "callback_data": "menu"}])
    return kb(rows)


def import_kb():
    return kb([[{"text": ".env (password + username)", "callback_data": "imp:wizenv"},
                {"text": ".env (password saja)", "callback_data": "imp:wizenvp"}],
               [{"text": "proxy.env", "callback_data": "imp:wizprop"},
                {"text": "TXT (user:pass@host:port)", "callback_data": "imp:wiztxt"}],
               [{"text": "⬅️ Kembali", "callback_data": "proxy"}]])


WIZ_FILES = {
    "wizprop": ("/home/ubuntu/workspace/projects/safelink-bot/proxy.env",
                "user+pass · proxy aktif sekarang (aman)"),
    "wizproxybot": ("/root/proxying-bot/.env",
                    "user+pass · zona proxying (isp_proxy2)"),
    "wiztokenharbor": ("/root/tokenharbor-bot/.env",
                       "user+pass · tokenharbor"),
    "wiztxt": ("/home/ubuntu/workspace/projects/safelink-bot/combo.txt",
               "TXT · user:pass@host:port"),
}


def wiz_files_list():
    rows = []
    for key, (path, label) in WIZ_FILES.items():
        mark = "✅" if os.path.exists(path) else "❌"
        # basename saja bikin ambigu (.env dari bot lain juga .env) -> tampilkan
        # dua komponen terakhir: "proxying-bot/.env", "tokenharbor-bot/.env"
        short = "/".join(path.split("/")[-2:])
        rows.append([{"text": f"{mark} {short} — {label}",
                      "callback_data": f"imp:{key}"}])
    rows.append([{"text": "⬅️ Kembali", "callback_data": "proxy"}])
    return kb(rows)


def _read_kv(path):
    kv = {}
    for line in open(path, errors="ignore"):
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, v = line.split("=", 1)
            kv[k.strip()] = v.strip()
    return kv


def _read_txt_line(path):
    for line in open(path, errors="ignore"):
        line = line.strip()
        if line and not line.startswith("#"):
            return line
    return ""


def do_import(chat_id, mid, key):
    """Ambil kredensial dari file di server, dites dulu, lalu tawarkan simpan.

    File dibaca LOKAL di server. Yang dipakai cuma PROXY_* — token bot / API key
    / kredensial lain di file itu TIDAK disentuh dan tidak pernah dikirim ke chat.
    """
    path, label = WIZ_FILES.get(key, (None, None))
    if not path or not os.path.exists(path):
        edit(chat_id, mid, f"❌ File tidak ada: `{path}`", proxy_kb())
        return
    cfg = _wiz_cfg_defaults()
    try:
        if key == "wiztxt":
            line = _read_txt_line(path)
            parsed = proxy_setup.parse_line(line) if line else None
            if not parsed:
                edit(chat_id, mid, "❌ Baris pertama file itu tidak bisa dibaca.\n"
                     "Format yang diterima: `user:pass@host:port`.", proxy_kb())
                return
            cfg.update(parsed)
            src = f"{path} (baris 1)"
        else:
            kv = _read_kv(path)
            fill = {"PROXY_USER": kv.get("PROXY_USER"),
                    "PROXY_PASS": kv.get("PROXY_PASS"),
                    "PROXY_HOST": kv.get("PROXY_HOST"),
                    "PROXY_PORT": kv.get("PROXY_PORT"),
                    "PROXY_COUNTRY": kv.get("PROXY_COUNTRY")}
            for k, v in fill.items():
                if v:
                    cfg[k] = v
            src = path
    except Exception as e:
        edit(chat_id, mid, f"❌ Gagal baca file: `{e}`", proxy_kb())
        return
    if not cfg.get("PROXY_PASS"):
        edit(chat_id, mid, f"❌ Tidak ada `PROXY_PASS` di `{path}`.\n"
             "Pakai 🛠 *Isi manual lengkap* kalau file itu cuma punya username.",
             proxy_kb())
        return
    if not cfg.get("PROXY_USER"):
        edit(chat_id, mid, f"⚠️ `{path}` tidak punya `PROXY_USER` (cuma password).\n"
             "Speed-dial: tekan 🛠 *Isi manual lengkap*, username diketik, "
             "password sudah terisi.", kb([
                 [{"text": "🛠 Isi manual lengkap", "callback_data": "wiz"}],
                 [{"text": "⬅️ Kembali", "callback_data": "proxy"}]]))
        s = read_state()
        s["wiz_pending"] = cfg
        _wiz_set(s, "user", cfg)      # masuk step 1: user cukup ketik username
        return
    mask = cfg["PROXY_PASS"][:2] + "***"
    ok, info = proxy_setup.check(_expand_proxy(cfg))
    s = read_state()
    clear_mode(s)
    write_state(s)
    s = read_state()
    s["wiz_pending"] = cfg
    write_state(s)
    edit(chat_id, mid,
         f"📥 Dibaca dari `{src}`\n"
         f"• User: `{cfg['PROXY_USER'][:56]}`\n"
         f"• Pass: `{mask}`\n"
         f"• Host: `{cfg.get('PROXY_HOST')}:{cfg.get('PROXY_PORT')}`\n\n"
         + ("✅ *Proxy jalan* — " if ok else "❌ *Proxy gagal* — ")
         + f"`{info}`\n\nSimpan yang ini ke proxy.env?", kb([
             [{"text": "💾 Simpan", "callback_data": "wizsave"}],
             [{"text": "🛠 Isi manual lengkap", "callback_data": "wiz"},
              {"text": "⬅️ Kembali", "callback_data": "proxy"}]]))


def _expand_proxy(cfg):
    """Ganti {country}/{session} biar bisa dites langsung."""
    import uuid as _uuid
    out = dict(cfg)
    out["PROXY_USER"] = (out.get("PROXY_USER") or "").replace(
        "{country}", out.get("PROXY_COUNTRY", "id")).replace(
        "{session}", "wiz" + _uuid.uuid4().hex[:8])
    return out


def _finalize_proxy(cfg):
    """Simpan hasil wizard ke proxy.env (0600) + refresh os.environ."""
    out = dict(cfg)
    out.setdefault("PROXY_HOST", proxy_setup.DEFAULTS["PROXY_HOST"])
    out.setdefault("PROXY_PORT", proxy_setup.DEFAULTS["PROXY_PORT"])
    out.setdefault("PROXY_COUNTRY", proxy_setup.DEFAULTS["PROXY_COUNTRY"])
    out.setdefault("USE_PROXY", "1")
    proxy_setup.save(out)
    return out


def _err_delete(chat_id, message_id, note):
    """Hapus pesan (kalau bisa) lalu kirim pesan error baru."""
    if message_id:
        r = api("deleteMessage", chat_id=chat_id, message_id=message_id)
        if not r.get("ok"):
            try:
                edit(chat_id, message_id, note)
                return
            except Exception:
                pass
    send(note, chat_id=chat_id)


def handle_wizard(msg, chat_id):
    """return True kalau pesan sudah ditangani wizard (jangan proses lagi)."""
    s = read_state()
    if s.get("mode") != "wiz":
        return False
    step = s.get("wiz") or "user"
    text = (msg.get("text") or "").strip()
    d = _wiz_data(s)
    mid = msg.get("message_id")

    if text.lower() in WIZ_CANCEL:
        clear_mode(s)
        write_state(s)
        send("✅ Wizard dibatalkan.\n\n" + proxy_text(), proxy_kb(), chat_id=chat_id)
        return True

    # ---------------- langkah 1-4: field per field
    if step in ("user", "pass", "host", "port"):
        if step == "user":
            if text in ("-", "default"):
                _wiz_set(s, "pass", d)
                send("⏭️ Username pakai yang tersimpan sekarang.\n\n"
                     "Langkah 2/5 — kirim *password* proxy.\n"
                     "Pesan ini gue hapus otomatis setelah dibaca.", chat_id=chat_id)
                return True
            if len(text) < 4 or ":" in text:
                send("❌ Kirim *username* proxy dulu (bukan password, bukan user+pw "
                     "digabung).\nContoh:\n"
                     "`brd-customer-hl_XXXXXXXX-zone-isp_proxy1`\n"
                     "(`-` = pakai username tersimpan · `/cancel` buat batal)",
                     chat_id=chat_id)
                return True
            d["PROXY_USER"] = text
            # password sudah kebaca dari file (import) -> langsung ke host,
            # jangan minta password dua kali
            if d.get("PROXY_PASS"):
                _wiz_set(s, "host", d)
                send(f"✅ Username: `{text[:56]}`\n"
                     "🔑 Password sudah terisi dari file import — dilewati.\n\n"
                     "Langkah berikutnya — kirim *host* proxy.\n"
                     "`-` = default `brd.superproxy.io`.", chat_id=chat_id)
                return True
            _wiz_set(s, "pass", d)
            send(f"✅ Username: `{text[:56]}`\n\n"
                 "Langkah 2/5 — kirim *password* proxy.\n"
                 "Pesan ini gue hapus otomatis setelah dibaca.", chat_id=chat_id)
            return True

        if step == "pass":
            if not text:
                send("❌ Password kosong. Kirim *password* proxy-nya.", chat_id=chat_id)
                return True
            d = _wiz_data(s)
            d["PROXY_PASS"] = text
            _wiz_set(s, "host", d)
            _err_delete(chat_id, mid, "✅ Password disimpan & pesan dihapus.\n\n"
                                      "Langkah 3/5 — kirim *host* proxy.\n"
                                      "`-` = default `brd.superproxy.io`.")
            return True

        if step == "host":
            if text in ("-", "skip", "default", ""):
                text = proxy_setup.DEFAULTS["PROXY_HOST"]
            d = _wiz_data(s)
            d["PROXY_HOST"] = text
            _wiz_set(s, "port", d)
            send(f"✅ Host: `{text}`\n\nLangkah 4/5 — kirim *port*.\n"
                 "`-` = default `44445` (BrightData).", chat_id=chat_id)
            return True

        if step == "port":
            if text in ("-", "skip", "default", ""):
                text = proxy_setup.DEFAULTS["PROXY_PORT"]
            if not text.isdigit():
                send("❌ Port harus angka. Contoh: `44445`", chat_id=chat_id)
                return True
            d = _wiz_data(s)
            d["PROXY_PORT"] = text
            _wiz_set(s, "country", d)
            send(f"✅ Port: `{text}`\n\nLangkah 5/5 — kirim *country* keluar "
                 "(2 huruf).\n`-` = pakai yang tersimpan "
                 f"`{d.get('PROXY_COUNTRY') or ENV.get('PROXY_COUNTRY','id')}`.\n\n"
                 "`id` `us` `de` `gb` `sg` `jp` ...", chat_id=chat_id)
            return True

    # ---------------- langkah 5: country -> cek -> simpan
    if step == "country":
        d = _wiz_data(s)
        if text and text not in ("-", "skip", "default"):
            if len(text) != 2 or not text.isalpha():
                send("❌ Country harus 2 huruf, contoh: `id`, `us`, `sg`.", chat_id=chat_id)
                return True
            d["PROXY_COUNTRY"] = text.lower()
        d.setdefault("PROXY_COUNTRY", proxy_setup.DEFAULTS["PROXY_COUNTRY"])
        if "{session}" not in d.get("PROXY_USER", ""):
            d["PROXY_USER"] = (d.get("PROXY_USER") or "") + "-session-{session}"
        if "{country}" not in d.get("PROXY_USER", ""):
            d["PROXY_USER"] = (d.get("PROXY_USER") or "") + "-country-{country}"
        send("🧪 Cek kredensial lewat proxy ...", chat_id=chat_id)
        ok, info = proxy_setup.check(_expand_proxy(d))
        _finalize_proxy(d)                      # disimpan walau tes gagal
        clear_mode(s)
        write_state(s)
        s = read_state()
        s.pop("wiz_pending", None)
        write_state(s)
        send((f"✅ *Proxy tersimpan & jalan* — `{info}`\n" if ok else
              f"⚠️ *Proxy tersimpan tapi tes gagal* — `{info}`\n"
              f"(kredensial tetap dimuat tiap view; cek user/pass/file)"
              "\n") + "\n" + proxy_text(),
             proxy_kb(), chat_id=chat_id)
        return True

    # ---------------- mode paste 1 baris
    if step == "paste":
        cfg, err = tokenize_line(text)
        if not cfg:
            send(f"❌ {err}.\nKirim satu baris, contoh:\n"
                 "`brd.superproxy.io:44445:brd-customer-hl_XXXX-zone-isp_proxy1:RAHASIA`\n"
                 "atau `user:pass@host:port`", chat_id=chat_id)
            return True
        send("🧪 Cek kredensial ...", chat_id=chat_id)
        ok, info = proxy_setup.check(cfg)
        proxy_setup.save(cfg)
        _err_delete(chat_id, mid, "✅ Paste diterima & pesan dihapus.\n"
                                  + ("✅ " if ok else "⚠️ ") + f"`{info}`")
        clear_mode(s)
        write_state(s)
        send(proxy_text(), proxy_kb(), chat_id=chat_id)
        return True

    # mode tidak dikenal -> reset
    clear_mode(s)
    write_state(s)
    send("Wizard direset.\n\n" + proxy_text(), proxy_kb(), chat_id=chat_id)
    return True


def proxy_kb():
    """Keyboard halaman Proxy (satu pintu: wizard + paste + import + tes + on/off)."""
    cfg = proxy_setup.load()
    state = "✅ on" if proxy_setup.configured() else "❌ kosong"
    rows = [
        [{"text": "🛠 Input manual (step-by-step)", "callback_data": "wiz"}],
        [{"text": "📋 Paste 1 baris (user:pass@host:port)", "callback_data": "paste"}],
        [{"text": "📥 Ambil dari file .env / .txt", "callback_data": "importfrom"}],
        [{"text": "🧪 Tes proxy tersimpan", "callback_data": "proxytest"},
         {"text": ("⏸️ Matikan" if cfg and cfg.get("USE_PROXY", "1") == "1"
                   else "▶️ Aktifkan"), "callback_data": "proxytoggle"}],
        [{"text": f"📄 Status: {state}", "callback_data": "proxy"},
         {"text": "⬅️ Menu", "callback_data": "menu"}],
    ]
    return kb(rows)


def kb(rows):
    return json.dumps({"inline_keyboard": rows})


def send(text, markup=None, chat_id=None):
    p = {"chat_id": chat_id or ALLOWED_CHAT, "text": text,
         "disable_web_page_preview": True}
    if markup:
        p["reply_markup"] = markup
    return api("sendMessage", **p)


def edit(chat_id, message_id, text, markup=None):
    p = {"chat_id": chat_id, "message_id": message_id, "text": text,
         "disable_web_page_preview": True}
    if markup:
        p["reply_markup"] = markup
    r = api("editMessageText", **p)
    # "message is not modified" = the panel already shows this exact state; that is
    # not an error worth reporting, and the caller still gets a truthful result.
    if not r.get("ok") and "not modified" in str(r.get("description", "")):
        return {"ok": True, "result": {"message_id": message_id}}
    return r


# ------------------------------------------------------------------ keyboards
def main_kb():
    s = read_state()
    link = s.get("link")
    cur_c = s.get("country", ENV.get("PROXY_COUNTRY", "id"))
    rows = [
        [{"text": "➕ Tambah link", "callback_data": "addlink"},
         {"text": "🎯 Jumlah view", "callback_data": "views"}],
        [{"text": f"🌍 Country: {cname(cur_c)}", "callback_data": "country"}],
        [{"text": "🔌 Proxy", "callback_data": "proxy"},
         {"text": "🛠 Input manual", "callback_data": "wiz"}],
        [{"text": "🚀 Jalankan sekarang", "callback_data": "confirm"}],
        [{"text": "📊 Status", "callback_data": "status"},
         {"text": "📈 Statistik", "callback_data": "stats"}],
        [{"text": "📋 Antrian", "callback_data": "queue"},
         {"text": "🗂️ Hasil terakhir", "callback_data": "results"}],
        [{"text": "🧹 Kosongkan antrian", "callback_data": "clearq"},
         {"text": "📦 Arsip + hapus histori", "callback_data": "clearh"}],
    ]
    return kb(rows)


def country_kb(cur):
    rows, row = [], []
    for c, label in COUNTRIES:
        mark = "✅ " if c == cur else ""
        row.append({"text": f"{mark}{label}", "callback_data": f"setc:{c}"})
        if len(row) == 2:
            rows.append(row)
            row = []
    if row:
        rows.append(row)
    rows.append([{"text": "⬅️ Kembali", "callback_data": "menu"}])
    return kb(rows)


def views_kb(n):
    rows = [[{"text": str(v), "callback_data": f"setv:{v}"} for v in VIEW_PRESETS[:3]],
            [{"text": str(v), "callback_data": f"setv:{v}"} for v in VIEW_PRESETS[3:]],
            [{"text": "✏️ Input manual", "callback_data": "views_manual"}],
            [{"text": "⬅️ Kembali", "callback_data": "menu"}]]
    return kb(rows)


# ------------------------------------------------------------------ texts
def menu_text():
    s = read_state()
    q = read_jobs()
    rows, ok = results_stats()
    cur_c = s.get("country", ENV.get("PROXY_COUNTRY", "id"))
    link = s.get("link")
    pend = s.get("pending_views", 1)
    active = worker_state()
    lines = ["🔓 *SafelinkU Bypass Bot*\n",
             f"• Antrian: {len(q)}  • Selesai: {len(rows)} (✅ {ok})",
             f"• Country aktif: {cname(cur_c)}"]
    pcfg = proxy_setup.load()
    if not pcfg:
        lines.append("• Proxy: ⚠️ belum diset (`/proxy`)")
    elif not proxy_setup.configured():
        lines.append("• Proxy: ❌ kredensial kosong (`/proxy`)")
    elif pcfg.get("USE_PROXY", "1") in ("0", "false", ""):
        lines.append("• Proxy: ⏸️ nonaktif (`/proxy on`)")
    else:
        lines.append(f"• Proxy: ✅ {pcfg.get('PROXY_COUNTRY','id').upper()} · "
                     f"{(pcfg.get('PROXY_HOST') or '')[:24]}")
    if active.get("url"):
        v, t = int(active.get("done", 0)) + 1, int(active.get("views", 1))
        lines.append(f"• Sedang jalan: view {v}/{t} · {active['url'][-28:]}")
    lines.append("")
    if link:
        lines.append(f"🎯 Link siap: `{link}`")
        lines.append(f"👁️ View diminta: *{pend}*")
        lines.append("\nTekan *Jalankan sekarang* atau ubah country / jumlah view.")
    else:
        lines.append("Kirim link safelink dulu, contoh:\n`https://sfl.gl/PpJU`  atau  `PpJU`")
    return "\n".join(lines)


def parse_urls(text):
    urls = []
    for tok in text.split():
        t = tok.strip()
        if t.startswith("http://") or t.startswith("https://"):
            urls.append(t)
        elif "/" not in t and 3 <= len(t) <= 20:
            urls.append("https://sfl.gl/" + t)   # bare alias like PpJU
    return urls


# ------------------------------------------------------------------ handlers
def handle_message(msg):
    chat_id = msg["chat"]["id"]
    text = (msg.get("text") or "").strip()
    if ALLOWED_CHAT and str(chat_id) != str(ALLOWED_CHAT):
        send("⛔ Akses ditolak.", chat_id=chat_id)
        return
    s = read_state()

    # a half-finished prompt must never be able to lock the panel: expire it.
    # Proxy wizard dikecualikan — kalau gagal di tengah, /proxy & /cancel tetap jalan.
    if s.get("mode") and s.get("mode") != "wiz" \
            and time.time() - float(s.get("mode_ts", 0)) > 600:
        clear_mode(s)
        write_state(s)

    # ---------------- commands first: they always work, whatever the mode is
    if text in ("/start", "/menu", "/help"):
        clear_mode(s)
        write_state(s)
        send(menu_text(), main_kb(), chat_id=chat_id)
        return

    if text in ("/cancel", "/batal", "/x"):
        clear_mode(s)
        write_state(s)
        send("✅ Dibatalkan.\n\n" + menu_text(), main_kb(), chat_id=chat_id)
        return

    if text.startswith("/setcountry"):
        parts = text.split()
        if len(parts) == 2 and any(c == parts[1] for c, _ in COUNTRIES):
            s["country"] = parts[1]
            clear_mode(s)
            write_state(s)
        send(menu_text(), main_kb(), chat_id=chat_id)
        return

    if text.startswith("/setviews"):
        parts = text.split()
        if len(parts) == 2 and parts[1].isdigit():
            s["pending_views"] = max(1, min(5000, int(parts[1])))
            clear_mode(s)
            write_state(s)
        send(menu_text(), main_kb(), chat_id=chat_id)
        return

    if text.startswith(PROXY_CMD) or text.startswith("/setproxy"):
        cmd = text.split("@", 1)[0]                    # buang suffix @botname
        rest = cmd.split(None, 1)[1].strip() if " " in cmd else ""
        low = rest.lower()
        if not rest:
            clear_mode(s)
            write_state(s)
            s = read_state()
            send(proxy_text() + "\n\n" + proxy_usage(), main_kb(), chat_id=chat_id)
            send("🛠 *Input proxy manual* — tekan tombol di bawah. "
                 "Ga perlu ketik satu baris panjang.", proxy_kb(), chat_id=chat_id)
            return
        if low in ("on", "off"):
            cfg = proxy_setup.load()
            if not cfg:
                send("⚠️ Proxy belum pernah diset. Kirim `/proxy user:pass@host:port` dulu.",
                     chat_id=chat_id)
                return
            cfg["USE_PROXY"] = "0" if low == "off" else "1"
            proxy_setup.save(cfg)
            send(f"✅ Proxy {'dimatikan (langsung IP server)' if low == 'off' else 'diaktifkan'}.\n\n"
                 + proxy_text(), main_kb(), chat_id=chat_id)
            return
        if low.startswith("country"):
            parts = rest.split()
            cfg = proxy_setup.load()
            if not cfg:
                send("⚠️ Proxy belum diset.", chat_id=chat_id)
                return
            if len(parts) == 2:
                cfg["PROXY_COUNTRY"] = parts[1].lower()
                proxy_setup.save(cfg)
                send(f"✅ Country keluar diset: *{cname(cfg['PROXY_COUNTRY'])}*\n\n"
                     + proxy_text(), main_kb(), chat_id=chat_id)
            else:
                send("Pakai: `/proxy country us`", chat_id=chat_id)
            return
        if low == "test":
            cfg = proxy_setup.load()
            if not cfg or not proxy_setup.configured():
                send("⚠️ Belum ada kredensial buat dites.", chat_id=chat_id)
                return
            send("🧪 Tes proxy ...", chat_id=chat_id)
            ok, info = proxy_setup.check(cfg)
            send(("✅ *Proxy jalan* — " if ok else "❌ *Proxy gagal* — ") + f"`{info}`\n\n"
                 + proxy_text(), main_kb(), chat_id=chat_id)
            return
        cfg = proxy_setup.parse_line(rest)
        if not cfg:
            send("❌ Format tidak dikenali.\n\n" + proxy_usage(), chat_id=chat_id)
            return
        send("🧪 Cek kredensial ...", chat_id=chat_id)
        ok, info = proxy_setup.check(cfg)
        proxy_setup.save(cfg)
        send((f"✅ Proxy disimpan & jalan — `{info}`\n\n" if ok else
              f"⚠️ Proxy disimpan tapi tes gagal — `{info}`\n\n") + proxy_text(),
             main_kb(), chat_id=chat_id)
        return

    # ---------------- wizard proxy manual (step-by-step)
    if s.get("mode") == "wiz" and handle_wizard(msg, chat_id):
        return

    urls = parse_urls(text)

    # ---------------- pending "how many views?" answer
    if s.get("mode") == "await_views":
        if text.isdigit() and 1 <= int(text) <= 5000:
            s["pending_views"] = int(text)
            clear_mode(s)
            write_state(s)
            send(f"✅ Jumlah view diset: *{s['pending_views']}*\n\n{menu_text()}",
                 main_kb(), chat_id=chat_id)
            return
        if not urls:
            # neither a number nor a link: only THEN complain about the number
            send("❌ Kirim angka 1-5000 buat jumlah view.\n"
                 "Mau kirim link aja? Boleh — link otomatis membatalkan prompt ini.\n"
                 "/cancel buat keluar.", chat_id=chat_id)
            return
        # a link arrived while the prompt was open -> drop the prompt, handle the link
        clear_mode(s)
        write_state(s)
    if not urls:
        if s.get("mode") == "await_link":
            send("➕ Kirim link safelink dulu, contoh:\n`https://sfl.gl/PpJU`\n"
                 "atau aliasnya `PpJU`. Kirim beberapa sekaligus juga bisa.",
                 kb([[{"text": "⬅️ Batal", "callback_data": "menu"}]]), chat_id=chat_id)
        else:
            send("Kirim link safelink, contoh:\n`https://sfl.gl/PpJU`\natau aliasnya: `PpJU`",
                 chat_id=chat_id)
        return

    # several links -> queue each with 1 view; one link -> stage it for options
    if len(urls) > 1:
        jobs = read_jobs()
        known = {j["url"] for j in jobs}
        added = [u for u in urls if u not in known]
        jobs.extend({"url": u, "views": 1,
                     "country": s.get("country", ENV.get("PROXY_COUNTRY", "id")),
                     "done": 0} for u in added)
        write_jobs(jobs)
        clear_mode(s)
        write_state(s)
        send(f"✅ {len(added)} link masuk antrian (1 view masing-masing).\n"
             f"Total antrian: {len(jobs)}\n\nAtur country: /setcountry us\n"
             f"Atur view: /setviews 50", chat_id=chat_id)
        return

    if s.get("mode") == "await_link":
        # add straight to the queue instead of overwriting the staged link
        jobs = read_jobs()
        jobs.append({"url": urls[0], "views": int(s.get("pending_views", 1) or 1),
                     "country": s.get("country", ENV.get("PROXY_COUNTRY", "id")),
                     "done": 0})
        write_jobs(jobs)
        clear_mode(s)
        write_state(s)
        send(f"✅ Masuk antrian: `{urls[0]}`\n"
             f"👁️ {int(s.get('pending_views', 1) or 1)} view · "
             f"🌍 {cname(s.get('country', 'id'))}\n"
             f"Total antrian: {len(jobs)}\n\n{menu_text()}", main_kb(), chat_id=chat_id)
        return

    s["link"] = urls[0]
    clear_mode(s)
    write_state(s)
    send(menu_text(), main_kb(), chat_id=chat_id)


def handle_callback(cq):
    chat_id = cq["message"]["chat"]["id"]
    mid = cq["message"]["message_id"]
    data = cq.get("data") or ""
    api("answerCallbackQuery", callback_query_id=cq["id"])
    if ALLOWED_CHAT and str(chat_id) != str(ALLOWED_CHAT):
        return
    s = read_state()

    if data == "menu":
        clear_mode(s)
        write_state(s)
        edit(chat_id, mid, menu_text(), main_kb())

    elif data == "wiz":
        have = proxy_setup.load() or {}
        _wiz_set(s, "user", {})
        note = ""
        if have.get("PROXY_USER"):
            note = (f"\nTersimpan sekarang: `{(have.get('PROXY_USER') or '')[:56]}`\n"
                    "(diisi ulang dari langkah 1)\n")
        edit(chat_id, mid,
             "🛠 *Input proxy manual — step-by-step*\n" + note +
             "\n*Langkah 1/5* — kirim *username* proxy saja (tanpa password).\n\n"
             "Contoh BrightData:\n"
             "`brd-customer-hl_XXXXXXXX-zone-isp_proxy1`\n\n"
             "`/cancel` kapan saja buat batal.",
             kb([[{"text": "⬅️ Batal", "callback_data": "proxy"}]]))

    elif data == "paste":
        _wiz_set(s, "paste", {})
        edit(chat_id, mid,
             "📋 *Paste 1 baris* — kirim dalam salah satu format:\n\n"
             "`user:pass@host:port`\n`host:port:user:pass`\n"
             "`host port user pass`\n`user pass host port`\n\n"
             "Contoh:\n`brd.superproxy.io:44445:brd-customer-hl_XXXX-zone-isp_proxy1:RAHASIA`\n\n"
             "Pesan lo gue hapus otomatis setelah dibaca.",
             kb([[{"text": "⬅️ Batal", "callback_data": "proxy"}]]))

    elif data == "importfrom":
        edit(chat_id, mid, "📥 *Ambil kredensial dari file di server*\n\n"
                           "Pilih sumber (✅ = file ada):", wiz_files_list())

    elif data.startswith("imp:"):
        do_import(chat_id, mid, data.split(":", 1)[1])

    elif data == "wizsave":
        cfg = s.get("wiz_pending") or {}
        if not cfg.get("PROXY_PASS"):
            edit(chat_id, mid, "⚠️ Tidak ada data buat disimpan. Ulangi wizard.",
                 proxy_kb())
            return
        if not cfg.get("PROXY_USER"):
            clear_mode(s)
            write_state(s)
            s2 = read_state()
            s2["wiz_data"] = cfg
            _wiz_set(s2, "user", cfg)
            edit(chat_id, mid, "🛠 *Lanjut isi username manual*\n\n*Langkah 1/5* — "
                 "kirim *username* proxy:", kb([[{"text": "⬅️ Batal",
                                                  "callback_data": "proxy"}]]))
            return
        if "{session}" not in cfg["PROXY_USER"]:
            cfg["PROXY_USER"] += "-session-{session}"
        if "{country}" not in cfg["PROXY_USER"]:
            cfg["PROXY_USER"] += "-country-{country}"
        _finalize_proxy(cfg)
        clear_mode(s)
        write_state(s)
        s = read_state()
        s.pop("wiz_pending", None)
        write_state(s)
        edit(chat_id, mid, "✅ *Proxy tersimpan ke proxy.env (0600)*\n\n"
             + proxy_text(), proxy_kb())

    elif data == "proxytoggle":
        cfg = proxy_setup.load()
        if not cfg or not proxy_setup.configured():
            edit(chat_id, mid, "⚠️ Belum ada kredensial proxy.\n\n" + proxy_text(),
                 proxy_kb())
            return
        cfg["USE_PROXY"] = "0" if cfg.get("USE_PROXY", "1") == "1" else "1"
        proxy_setup.save(cfg)
        edit(chat_id, mid, ("⏸️ Proxy *dimatikan* (view lewat IP server — "
                            "rawan di-dedupe).\n\n" if cfg["USE_PROXY"] == "0"
                            else "▶️ Proxy *diaktifkan*.\n\n") + proxy_text(), proxy_kb())

    elif data == "addlink":
        s["mode"], s["mode_ts"] = "await_link", time.time()
        write_state(s)
        edit(chat_id, mid,
             "➕ *Tambah link*\n\nKirim link safelink sekarang.\n"
             "Contoh: `https://sfl.gl/PpJU`  atau aliasnya `PpJU`\n\n"
             "Kirim beberapa sekaligus juga bisa (1 view masing-masing).",
             kb([[{"text": "⬅️ Batal", "callback_data": "menu"}]]))

    elif data == "nolink":
        edit(chat_id, mid, "➕ Kirim link dulu — tekan *Tambah link*, "
                           "atau langsung kirim linknya ke chat ini.", main_kb())

    elif data == "country":
        cur = s.get("country", ENV.get("PROXY_COUNTRY", "id"))
        edit(chat_id, mid, f"🌍 *Pilih country*\n\nAktif: {cname(cur)}\n"
                           f"(IP residential benar-benar keluar dari negara itu)",
             country_kb(cur))

    elif data == "proxy":
        edit(chat_id, mid, proxy_text() + "\n\n🛠 *Input manual* — pilih cara di bawah "
             "(ga perlu ketik panjang):\n\n" + proxy_usage(), proxy_kb())

    elif data == "proxytest":
        cfg = proxy_setup.load()
        if not cfg or not proxy_setup.configured():
            edit(chat_id, mid, "⚠️ Belum ada kredensial proxy buat dites.\n\n" + proxy_usage(),
                 main_kb())
            return
        edit(chat_id, mid, "🧪 Tes proxy ...\n\n" + proxy_text(), main_kb())
        ok, info = proxy_setup.check(cfg)
        edit(chat_id, mid, ("✅ *Proxy jalan* — " if ok else "❌ *Proxy gagal* — ")
             + f"`{info}`\n\n" + proxy_text(), main_kb())

    elif data.startswith("setc:"):
        s["country"] = data.split(":", 1)[1]
        write_state(s)
        edit(chat_id, mid, f"✅ Country diset: *{cname(s['country'])}*\n\n{menu_text()}",
             main_kb())

    elif data == "views":
        n = s.get("pending_views", 1)
        edit(chat_id, mid, f"👁️ *Jumlah view manual*\n\nSekarang: *{n}*\n\n"
                           f"Pilih preset, atau *Input manual* (tekan lalu kirim angka 1-5000).",
             views_kb(n))

    elif data.startswith("setv:"):
        s["pending_views"] = int(data.split(":", 1)[1])
        clear_mode(s)
        write_state(s)
        edit(chat_id, mid, f"✅ Jumlah view diset: *{s['pending_views']}*\n\n{menu_text()}",
             main_kb())

    elif data == "views_manual":
        s["mode"], s["mode_ts"] = "await_views", time.time()
        write_state(s)
        edit(chat_id, mid, "✏️ *Input manual*\n\nKirim angka jumlah view (1-5000).\n"
             "(Kirim link juga boleh — prompt ini otomatis batal.)",
             kb([[{"text": "⬅️ Batal", "callback_data": "menu"}]]))

    elif data == "confirm":
        link = s.get("link")
        if not link:
            if read_jobs():
                edit(chat_id, mid, f"✅ Antrian sudah jalan ({len(read_jobs())} job).\n\n"
                     "Tekan *➕ Tambah link* kalau mau tambah lagi.\n\n" + menu_text(),
                     main_kb())
            else:
                edit(chat_id, mid, "➕ Belum ada link. Tekan *Tambah link* dulu, "
                                   "atau langsung kirim link ke chat ini.", main_kb())
            return
        n = int(s.get("pending_views", 1))
        c = s.get("country", ENV.get("PROXY_COUNTRY", "id"))
        jobs = read_jobs()
        jobs.insert(0, {"url": link, "views": n, "country": c, "done": 0})
        write_jobs(jobs)
        s["link"] = None
        clear_mode(s)
        write_state(s)
        edit(chat_id, mid, f"🚀 *Dimasukkan ke antrian*\n\n"
                           f"🔗 {link}\n👁️ {n} view\n🌍 {cname(c)}\n\n"
                           f"Worker jalan otomatis. Progress dikirim ke chat ini.\n\n"
                           f"{menu_text()}", main_kb())

    elif data == "status":
        rows, ok = results_stats()
        last = rows[-1] if rows else None
        w = subprocess.run(["systemctl", "is-active", "safelink-worker"],
                           capture_output=True, text=True).stdout.strip()
        p = subprocess.run(["systemctl", "is-active", "safelink-bot"],
                           capture_output=True, text=True).stdout.strip()
        act = worker_state()
        txt = (f"📊 *Status*\n\n"
               f"• Antrian: {len(read_jobs())}\n"
               f"• Selesai: {len(rows)} (✅ {ok} / ⚠️ {len(rows)-ok})\n"
               f"• Panel: `{p}`  • Worker: `{w}`\n")
        if act.get("url"):
            txt += (f"• Jalan: view {int(act.get('done',0))+1}/{int(act.get('views',1))} · "
                    f"{cname(act.get('country','?'))}\n")
        if last:
            txt += f"\nTerakhir: {'✅' if last.get('ok') else '⚠️'}\n`{(last.get('final') or last.get('input'))[:120]}`"
        edit(chat_id, mid, txt, main_kb())

    elif data == "stats":
        rows, ok = results_stats()
        by_c, by_dev = {}, {}
        for r in rows:
            if r.get("ok"):
                by_c[r.get("country", "?")] = by_c.get(r.get("country", "?"), 0) + 1
                d = (r.get("device") or {}).get("platform", "?")
                by_dev[d] = by_dev.get(d, 0) + 1
        txt = (f"📈 *Statistik*\n\nTotal: {len(rows)}\nBerhasil: {ok}\n"
               f"Gagal: {len(rows)-ok}\n"
               f"Success rate: {int(ok/len(rows)*100) if rows else 0}%\n")
        if by_c:
            txt += "\nPer country:\n" + "\n".join(
                f"• {cname(c)}: {n}" for c, n in sorted(by_c.items(), key=lambda x: -x[1]))
        if by_dev:
            txt += "\n\nDevice terpakai:\n" + "\n".join(
                f"• {d}: {n}" for d, n in sorted(by_dev.items(), key=lambda x: -x[1])[:6])
        edit(chat_id, mid, txt, main_kb())

    elif data == "queue":
        q = read_jobs()
        if not q:
            edit(chat_id, mid, "📋 *Antrian*\n\n(kosong)", main_kb())
            return
        txt = f"📋 *Antrian* ({len(q)} job)\n"
        for i, j in enumerate(q[:12], 1):
            left = int(j.get("views", 1)) - int(j.get("done", 0))
            txt += f"\n{i}. `{j['url'][-28:]}`\n    {left} view · {cname(j.get('country','?'))}"
        if len(q) > 12:
            txt += f"\n... +{len(q)-12} lagi"
        edit(chat_id, mid, txt, main_kb())

    elif data == "results":
        rows, _ = results_stats()
        if not rows:
            edit(chat_id, mid, "🗂️ Belum ada hasil.", main_kb())
            return
        txt = "🗂️ *Hasil terakhir*\n"
        for r in rows[-8:]:
            icon = "✅" if r.get("ok") else "⚠️"
            txt += (f"\n{icon} `{r.get('input','')[-22:]}` "
                    f"[{r.get('country','?')}] v{r.get('view','?')}\n"
                    f"   → `{(r.get('final') or r.get('error') or '-')[:84]}`")
        edit(chat_id, mid, txt, main_kb())

    elif data == "clearq":
        n = len(read_jobs())
        write_jobs([])
        edit(chat_id, mid, f"🧹 Antrian dikosongkan ({n} job dibuang).", main_kb())

    elif data == "clearh":
        rows = read_lines(RESULTS)
        if rows:
            with open(ARCHIVE, "a") as f:
                f.write(f"# --- backup {time.strftime('%Y-%m-%d %H:%M:%S')} ---\n")
                for r in rows:
                    f.write(r + "\n")
        open(RESULTS, "w").close()
        edit(chat_id, mid, f"📦 {len(rows)} hasil diarsipkan, histori dikosongkan.", main_kb())


def main():
    global OFFSET, API, ALLOWED_CHAT
    load_env()
    # --- proxy manual (BrightData): diminta saat bot dijalankan --------------
    # Di TTY: prompt interaktif. Di bawah systemd (bukan TTY): load proxy.env
    # yang sudah ada; kalau belum ada, operator set lewat command /proxy.
    try:
        proxy_setup.interactive()
    except Exception as e:
        logging.error("proxy setup gagal: %s", e)
    token = ENV.get("TELEGRAM_BOT_TOKEN")
    if not token:
        logging.error("no TELEGRAM_BOT_TOKEN")
        sys.exit(1)
    lock = acquire_lock()          # keep the handle alive for the whole process
    API = f"https://api.telegram.org/bot{token}"
    ALLOWED_CHAT = ENV.get("TELEGRAM_CHAT_ID")
    globals()["SESSION"] = make_session()
    # resume from the last acknowledged update. progress is persisted on EVERY
    # update, so a restart/crash can never replay old commands or lose a new one.
    OFFSET = load_offset()
    if OFFSET is None:
        res = (api_with_timeout("getUpdates", offset=-1, timeout=0).get("result") or [])
        OFFSET = (res[-1]["update_id"] + 1) if res else 0
        save_offset(OFFSET)
    me = api("getMe").get("result", {})
    logging.info("panel online as @%s (chat=%s, offset=%s)", me.get("username"),
                 ALLOWED_CHAT, OFFSET)
    set_commands()
    fails = 0

    while True:
        try:
            Path(HB).touch()
        except Exception:
            pass
        try:
            # read(70) MUST exceed the long-poll timeout(25) or every idle poll
            # dies with "Read timed out" -- the bot then looks online but blind.
            r = SESSION.get(f"{API}/getUpdates",
                            params={"offset": OFFSET, "timeout": 25},
                            timeout=(10, 70))
            data = r.json()
            for up in data.get("result", []):
                OFFSET = up["update_id"] + 1
                save_offset(OFFSET)          # persist BEFORE handling
                try:
                    if "message" in up:
                        handle_message(up["message"])
                    elif "callback_query" in up:
                        handle_callback(up["callback_query"])
                except Exception as e:
                    logging.error("handle update failed: %s", e)
            fails = 0
        except Exception as e:
            fails += 1
            logging.warning("poll failed #%d: %s", fails, e)
            # drop the poisoned socket, else the retry reuses the same dead one
            try:
                SESSION.close()
            except Exception:
                pass
            globals()["SESSION"] = make_session()
            time.sleep(min(2 * fails, 10))


def api_with_timeout(method, **params):
    """Same as api() but never blocks long: used before the poll loop starts."""
    try:
        return SESSION.post(f"{API}/{method}", json=params, timeout=(6, 20)).json()
    except Exception as e:
        logging.warning("api_with_timeout %s: %s", method, e)
        return {}


if __name__ == "__main__":
    main()
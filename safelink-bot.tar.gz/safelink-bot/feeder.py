#!/usr/bin/python3
"""feeder.py — isi queue.txt terus-menerus dengan rotasi link.

Worker paket ini cuma bisa satu job sekaligus (dia ambil job pertama lalu tulis
ulang queue.txt), jadi jangan pernah menulis ke queue selagi ada job in-flight:
entri baru bisa hilang ditimpa. Aturan aman di sini:

    tulis job baru HANYA kalau queue.txt kosong DAN state.json kosong
    (artinya worker sedang tidak memegang job).

Kalau ada benturan kecil, tidak ada yang hilang permanen — feeder cek lagi
15 detik kemudian dan menulis ulang. Link dirotasi berurutan lalu balik ke awal.

Pakai:
    python3 feeder.py                 # rotasi semua link di links.txt
    python3 feeder.py --delay 30      # jeda antar view (detik)
    python3 feeder.py --once          # isi satu job lalu keluar (buat tes)
"""
import argparse
import json
import os
import time

HERE = os.path.dirname(os.path.abspath(__file__))
QUEUE = os.path.join(HERE, "queue.txt")
STATE = os.path.join(HERE, "state.json")
LINKS = os.path.join(HERE, "links.txt")
PROGRESS = os.path.join(HERE, ".feed_progress")   # index link terakhir


def read_links():
    out = []
    for ln in open(LINKS):
        ln = ln.strip()
        if ln and not ln.startswith("#"):
            if not ln.startswith("http"):
                ln = "https://sfl.gl/" + ln
            out.append(ln)
    return out


def queue_empty():
    try:
        return os.path.getsize(QUEUE) == 0
    except OSError:
        return True


def state_idle():
    try:
        with open(STATE) as fh:
            return not (json.load(fh) or {}).get("url")
    except Exception:
        return True


def last_index():
    try:
        return int(open(PROGRESS).read().strip())
    except Exception:
        return -1


def write_progress(i):
    with open(PROGRESS, "w") as fh:
        fh.write(str(i))


def enqueue(link, views, country):
    job = {"url": link, "views": views, "country": country, "done": 0}
    tmp = QUEUE + ".tmp"
    with open(tmp, "w") as fh:
        fh.write(json.dumps(job, ensure_ascii=False) + "\n")
    os.replace(tmp, QUEUE)          # atomik: worker tidak lihat file separuh
    return job


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--delay", type=float, default=120, help="jeda antar view (detik)")
    ap.add_argument("--views", type=int, default=1, help="view per link")
    ap.add_argument("--country", default="id")
    ap.add_argument("--once", action="store_true")
    args = ap.parse_args()

    links = read_links()
    if not links:
        print("[feeder] links.txt kosong"); return 1
    print(f"[feeder] {len(links)} link, delay {args.delay}s, views/link {args.views}", flush=True)

    i = last_index()
    while True:
        if queue_empty() and state_idle():
            i = (i + 1) % len(links)
            job = enqueue(links[i], args.views, args.country)
            write_progress(i)
            print(f"[feeder] queue <- {job['url']} (link {i+1}/{len(links)})", flush=True)
            if args.once:
                return 0
            time.sleep(args.delay)
        else:
            time.sleep(5)


if __name__ == "__main__":
    raise SystemExit(main())

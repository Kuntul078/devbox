#!/usr/bin/python3
"""
Per-view device + fingerprint spoofing for the safelink bypass.

SafelinkU hashes webgl + audio + canvas + fonts + system + env + network
(weighted, SHA-256) into the _token it posts to /api/session. A constant hash
means "same device", so the publisher only ever gets ONE credited view from us.
This module makes each attempt look like a different real device: a consistent
UA/platform/screen/GPU/locale set plus per-session noise in the hashed
primitives (canvas, audio, WebGL strings, font availability, network info).
"""
import json
import os
import random
import uuid

# (ua, platform, screen(w,h), dpr, touch, family)
UA_POOL = [
    # Android — most Indonesian safelink traffic is mobile
    ("Mozilla/5.0 (Linux; Android 13; SM-A536E) AppleWebKit/537.36 (KHTML, like Gecko) "
     "Chrome/131.0.0.0 Mobile Safari/537.36", "Linux armv8l", (412, 915), 2.625, 5, "android"),
    ("Mozilla/5.0 (Linux; Android 14; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) "
     "Chrome/132.0.0.0 Mobile Safari/537.36", "Linux armv8l", (412, 915), 2.625, 5, "android"),
    ("Mozilla/5.0 (Linux; Android 12; Redmi Note 10) AppleWebKit/537.36 (KHTML, like Gecko) "
     "Chrome/131.0.0.0 Mobile Safari/537.36", "Linux armv8l", (393, 851), 2.75, 5, "android"),
    ("Mozilla/5.0 (Linux; Android 13; Infinix X6815) AppleWebKit/537.36 (KHTML, like Gecko) "
     "Chrome/130.0.0.0 Mobile Safari/537.36", "Linux armv8l", (360, 800), 3.0, 5, "android"),
    ("Mozilla/5.0 (Linux; Android 14; vivo 1906) AppleWebKit/537.36 (KHTML, like Gecko) "
     "Chrome/132.0.0.0 Mobile Safari/537.36", "Linux armv8l", (360, 804), 3.0, 5, "android"),
    ("Mozilla/5.0 (Linux; Android 11; OPPO A54) AppleWebKit/537.36 (KHTML, like Gecko) "
     "Chrome/130.0.0.0 Mobile Safari/537.36", "Linux armv8l", (360, 800), 3.0, 5, "android"),
    # Windows desktop
    ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
     "Chrome/131.0.0.0 Safari/537.36", "Win32", (1920, 1080), 1.0, 0, "win"),
    ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
     "Chrome/132.0.0.0 Safari/537.36", "Win32", (1536, 864), 1.25, 0, "win"),
    ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
     "Chrome/133.0.0.0 Safari/537.36", "Win32", (1366, 768), 1.0, 0, "win"),
    # macOS
    ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) "
     "Chrome/131.0.0.0 Safari/537.36", "MacIntel", (2560, 1440), 2.0, 0, "mac"),
]

GPUS = {
    "android": [("Qualcomm", "Adreno (TM) 640"), ("Qualcomm", "Adreno (TM) 650"),
                ("ARM", "Mali-G76 MP12"), ("ARM", "Mali-G52 MC2"),
                ("Imagination Technologies", "PowerVR Rogue GE8320")],
    "win": [("Google Inc. (NVIDIA)", "ANGLE (NVIDIA, NVIDIA GeForce RTX 3060 Direct3D11 vs_5_0 ps_5_0, D3D11)"),
            ("Google Inc. (NVIDIA)", "ANGLE (NVIDIA, NVIDIA GeForce GTX 1650 Direct3D11 vs_5_0 ps_5_0, D3D11)"),
            ("Google Inc. (Intel)", "ANGLE (Intel, Intel(R) UHD Graphics 620 Direct3D11 vs_5_0 ps_5_0, D3D11)"),
            ("Google Inc. (Intel)", "ANGLE (Intel, Intel(R) Iris(R) Xe Graphics Direct3D11 vs_5_0 ps_5_0, D3D11)"),
            ("Google Inc. (AMD)", "ANGLE (AMD, AMD Radeon RX 580 Direct3D11 vs_5_0 ps_5_0, D3D11)")],
    "mac": [("Google Inc. (Apple)", "ANGLE (Apple, Apple M1, OpenGL 4.1)"),
            ("Google Inc. (Apple)", "ANGLE (Apple, Apple M2, OpenGL 4.1)"),
            ("Google Inc. (Intel)", "ANGLE (Intel, Intel(R) Iris(TM) Plus Graphics 640, OpenGL 4.1)")],
}

CPU = {"android": [4, 8], "win": [4, 8, 12, 16], "mac": [4, 8, 10]}
MEM = {"android": [4, 6, 8], "win": [8, 16], "mac": [8, 16]}

# locale/tz coherence per country so the proxy IP is not contradicted
LOCALES = {
    "id": {"langs": [("id-ID", ["id-ID", "id", "en-US", "en"]),
                     ("id-ID", ["id-ID", "en-US", "en"])],
           "tz": ["Asia/Jakarta", "Asia/Makassar", "Asia/Jayapura", "Asia/Pontianak"]},
    "us": {"langs": [("en-US", ["en-US", "en"])],
           "tz": ["America/New_York", "America/Chicago", "America/Los_Angeles",
                  "America/Phoenix"]},
    "gb": {"langs": [("en-GB", ["en-GB", "en"])], "tz": ["Europe/London"]},
    "de": {"langs": [("de-DE", ["de-DE", "de", "en-US", "en"])], "tz": ["Europe/Berlin"]},
    "sg": {"langs": [("en-SG", ["en-SG", "en", "zh-CN"])], "tz": ["Asia/Singapore"]},
    "my": {"langs": [("ms-MY", ["ms-MY", "ms", "en-US", "en"])], "tz": ["Asia/Kuala_Lumpur"]},
    "jp": {"langs": [("ja-JP", ["ja-JP", "ja", "en-US", "en"])], "tz": ["Asia/Tokyo"]},
    "in": {"langs": [("en-IN", ["en-IN", "en", "hi-IN"])], "tz": ["Asia/Kolkata"]},
    "br": {"langs": [("pt-BR", ["pt-BR", "pt", "en-US", "en"])],
           "tz": ["America/Sao_Paulo"]},
    "fr": {"langs": [("fr-FR", ["fr-FR", "fr", "en-US", "en"])], "tz": ["Europe/Paris"]},
    "nl": {"langs": [("nl-NL", ["nl-NL", "nl", "en-US", "en"])], "tz": ["Europe/Amsterdam"]},
    "_": {"langs": [("en-US", ["en-US", "en"])], "tz": ["Asia/Jakarta"]},
}

COUNTRIES = [
    ("id", "🇮🇩 Indonesia"), ("us", "🇺🇸 Amerika"), ("gb", "🇬🇧 Inggris"),
    ("de", "🇩🇪 Jerman"), ("sg", "🇸🇬 Singapura"), ("my", "🇲🇾 Malaysia"),
    ("jp", "🇯🇵 Jepang"), ("in", "🇮🇳 India"), ("br", "🇧🇷 Brazil"),
    ("fr", "🇫🇷 Prancis"), ("nl", "🇳🇱 Belanda"),
]

NET = ["4g|10|100", "4g|8.35|150", "4g|5.2|250", "3g|1.45|350", "4g|20|50"]

FONTS = ["Arial", "Arial Black", "Bookman Old Style", "Comic Sans MS", "Courier New",
         "Georgia", "Helvetica", "Impact", "Palatino Linotype", "Tahoma",
         "Times New Roman", "Trebuchet MS", "Verdana", "Wingdings", "Segoe UI",
         "Calibri", "Cambria", "Consolas", "Franklin Gothic Medium", "Helvetica Neue",
         "San Francisco", "Ubuntu", "Noto Sans", "Roboto", "Fira Code"]


def pick_profile(country="id", mobile_bias=0.65):
    """Return a self-consistent device profile: UA == platform == screen == GPU == locale/tz."""
    pool = UA_POOL
    if random.random() > mobile_bias:
        pool = [u for u in UA_POOL if u[5] != "android"]
    ua, platform, screen, dpr, touch, family = random.choice(pool)
    vendor, renderer = random.choice(GPUS[family])
    loc = LOCALES.get(country, LOCALES["_"])
    lang, langs = random.choice(loc["langs"])
    return {
        "ua": ua, "platform": platform, "screen": (screen[0], screen[1]), "dpr": dpr,
        "touch": touch, "family": family, "vendor": vendor, "renderer": renderer,
        "cpu": random.choice(CPU[family]), "mem": random.choice(MEM[family]),
        "lang": lang, "langs": langs, "tz": random.choice(loc["tz"]),
        "net": random.choice(NET),
        "seed": random.randint(1, 2 ** 31 - 1),
        "flip": random.sample(FONTS, random.randint(1, 3)),
    }


_INIT_BODY = r"""
  // --- stealth core (Patchright ignores add_init_script, so we carry our own)
  try {
    d(Navigator.prototype, 'webdriver', {get: () => false});
    if (!window.chrome) window.chrome = {};
    if (!window.chrome.runtime) window.chrome.runtime = {};
    // strip the CDP-injected markers
    for (const k of Object.getOwnPropertyNames(window)) {
      if (/^cdc_|\$cdc|^__playwright|^__pw|^__driver/i.test(k)) {
        try { delete window[k]; } catch (e) {}
      }
    }
    // notifications default-deny looks like a real fresh profile
    if (window.Notification) {
      try { d(Notification, 'permission', {get: () => 'default'}); } catch (e) {}
    }
    // permissions.query must not leak "denied" for notifications on a real device
    if (navigator.permissions && navigator.permissions.query) {
      const q = navigator.permissions.query.bind(navigator.permissions);
      navigator.permissions.query = function (p) {
        if (p && p.name === 'notifications') {
          return Promise.resolve({state: Notification.permission, onchange: null});
        }
        return q(p);
      };
    }
  } catch (e) {}

  // --- navigator consistency (feeds the "system" hash, weight 1.5)
  try {
    d(Navigator.prototype, 'platform',            {get: () => P.platform});
    d(Navigator.prototype, 'hardwareConcurrency', {get: () => P.cpu});
    d(Navigator.prototype, 'deviceMemory',        {get: () => P.mem});
    d(Navigator.prototype, 'maxTouchPoints',      {get: () => P.touch});
    d(Navigator.prototype, 'language',            {get: () => P.lang});
    d(Navigator.prototype, 'languages',           {get: () => Object.freeze(P.langs)});
    d(Navigator.prototype, 'webdriver',           {get: () => false});
  } catch (e) {}

  // --- screen / dpr (feeds the "env" hash, weight 1)
  try {
    d(window.screen, 'width',       {get: () => P.screen[0]});
    d(window.screen, 'height',      {get: () => P.screen[1]});
    d(window.screen, 'availWidth',  {get: () => P.screen[0]});
    d(window.screen, 'availHeight', {get: () => P.screen[1] - (P.touch ? 24 : 40)});
    d(window.screen, 'colorDepth',  {get: () => 24});
    d(window.screen, 'pixelDepth',  {get: () => 24});
    d(window, 'devicePixelRatio',   {get: () => P.dpr});
  } catch (e) {}

  // --- network information (hashed, weight 0.5)
  try {
    const n = P.net.split('|');
    const conn = {effectiveType: n[0], downlink: parseFloat(n[1]),
                  rtt: parseInt(n[2], 10), saveData: false};
    d(Navigator.prototype, 'connection', {get: () => conn});
  } catch (e) {}

  // --- WebGL vendor/renderer (hashed, weight 3). With --enable-unsafe-swiftshader
  // the context exists but reports SwiftShader; override BOTH the extension and the
  // plain RENDERER/VENDOR queries, and the unmasked strings, so it reads as a real GPU.
  try {
      const patch = function (proto) {
        const g = proto.getParameter;
        proto.getParameter = function (x) {
          if (x === 37445 || x === 7936) return P.vendor;
          if (x === 37446 || x === 7937) return P.renderer;
          return g.call(this, x);
        };
        const e = proto.getExtension;
        proto.getExtension = function (name) {
          const ext = e.call(this, name);
          if (name === 'WEBGL_debug_renderer_info' && ext) {
            try {
              Object.defineProperty(ext, 'UNMASKED_VENDOR_WEBGL', {get: () => 37445});
              Object.defineProperty(ext, 'UNMASKED_RENDERER_WEBGL', {get: () => 37446});
            } catch (err) {}
          }
          return ext;
        };
      };
      if (window.WebGLRenderingContext) patch(WebGLRenderingContext.prototype);
      if (window.WebGL2RenderingContext) patch(WebGL2RenderingContext.prototype);
    } catch (e) {}

  // --- canvas noise (hashed, weight 2)
  try {
    const o = HTMLCanvasElement.prototype.toDataURL;
    HTMLCanvasElement.prototype.toDataURL = function () {
      try {
        const c = this.getContext('2d');
        if (c && this.width > 0 && this.height > 0) {
          const px = c.getImageData(0, 0, 1, 1);
          px.data[0] = (px.data[0] + SEED) & 255;
          c.putImageData(px, 0, 0);
        }
      } catch (e) {}
      return o.apply(this, arguments);
    };
  } catch (e) {}

  // --- audio noise (hashed, weight 3)
  try {
    const o = AudioBuffer.prototype.getChannelData;
    AudioBuffer.prototype.getChannelData = function () {
      const buf = o.apply(this, arguments);
      try {
        const eps = (SEED % 997) * 1e-9;
        const lim = Math.min(buf.length, 500);
        for (let i = 0; i < lim; i += 7) buf[i] = buf[i] + eps;
      } catch (e) {}
      return buf;
    };
  } catch (e) {}

  // --- fonts (hashed, weight 2): hide a device-specific subset
  try {
    const FLIP = P.flip;
    const oc = FontFaceSet.prototype.check;
    FontFaceSet.prototype.check = function (font, text) {
      let r;
      try { r = oc.call(this, font, text); } catch (e) { r = false; }
      try {
        for (let i = 0; i < FLIP.length; i++) {
          if (font.indexOf(FLIP[i]) !== -1) r = !r;
        }
      } catch (e) {}
      return r;
    };
  } catch (e) {}
})();
"""


def init_js(p):
    """Init script making every hashed primitive unique but internally coherent."""
    data = json.dumps({
        "ua": p["ua"], "platform": p["platform"], "screen": list(p["screen"]),
        "dpr": p["dpr"], "touch": p["touch"], "family": p["family"],
        "vendor": p["vendor"], "renderer": p["renderer"], "cpu": p["cpu"],
        "mem": p["mem"], "lang": p["lang"], "langs": p["langs"], "tz": p["tz"],
        "net": p["net"], "seed": p["seed"], "flip": p["flip"],
    }, ensure_ascii=False)
    return ("(() => {\n  const P = " + data +
            ";\n  const d = Object.defineProperty;\n  const SEED = P.seed;\n" +
            _INIT_BODY)


def profile_dir():
    # Portable: ikut lokasi file ini (biar jalan di runner GitHub/VPS lain juga,
    # bukan cuma di /home/ubuntu). Bisa dioverride lewat env SL_PROFILE_DIR.
    base = os.environ.get("SL_PROFILE_DIR") or os.path.join(os.path.dirname(os.path.abspath(__file__)), ".profiles")
    return os.path.join(base, uuid.uuid4().hex[:12])


if __name__ == "__main__":
    for _ in range(3):
        p = pick_profile("id")
        print(json.dumps({k: p[k] for k in ("ua", "platform", "screen", "vendor",
                                            "renderer", "cpu", "mem", "lang", "tz",
                                            "seed", "flip")}, ensure_ascii=False))
    js = init_js(pick_profile("id"))
    print("\ninit_js bytes:", len(js))
#!/usr/bin/python3
"""
Canary for the safelink-bot Telegram panel.

Why this exists: `systemctl is-active` and a fresh heartbeat file only prove the
process is alive. A panel whose socket to api.telegram.org is dead, or whose
getUpdates loop keeps timing out, still looks ACTIVE and its heartbeat still
ticks -- while it silently answers nothing. This canary performs the real API
calls and touches /home/ubuntu/workspace/projects/safelink-bot/.bot-heartbeat/safelink-canary.hb only when healthy.
When the heartbeat goes stale, the watchdog restarts the panel (and worker).

Add to /root/bot-watchdog.py: put "safelink-canary" in BOTS with HB_OPTIONAL
semantics for the systemctl check (it is not a unit) and heal the stack instead.
"""
import json
import os
import sys
import time
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
ENV = {}
for line in open(os.path.join(HERE, ".env")):
    line = line.strip()
    if "=" in line and not line.startswith("#"):
        k, v = line.split("=", 1)
        ENV[k.strip()] = v.strip()

HB = "/home/ubuntu/workspace/projects/safelink-bot/.bot-heartbeat/safelink-canary.hb"
STATE = os.path.join(HERE, "state.json")
WORKER_HB = "/home/ubuntu/workspace/projects/safelink-bot/.bot-heartbeat/safelink-worker.hb"


def api(method, **params):
    tok = ENV["TELEGRAM_BOT_TOKEN"]
    q = "&".join(f"{k}={v}" for k, v in params.items())
    url = f"https://api.telegram.org/bot{tok}/{method}"
    if q:
        url += "?" + q
    req = urllib.request.Request(url)
    with urllib.request.urlopen(req, timeout=20) as r:
        return json.loads(r.read())


def main():
    problems = []
    try:
        j = api("getUpdates", offset=-1, timeout=0)
        if not j.get("ok"):
            problems.append("getUpdates not ok")
    except Exception as e:
        problems.append(f"api unreachable: {type(e).__name__}")

    try:
        st = json.load(open(STATE))
    except Exception:
        st = {}
    if st.get("url"):
        try:
            age = time.time() - os.path.getmtime(WORKER_HB)
            if age > 240:
                problems.append(f"worker heartbeat stale {int(age)}s")
        except Exception:
            problems.append("worker heartbeat missing with job in flight")

    if problems:
        print("UNHEALTHY:", "; ".join(problems))
        return 1
    os.makedirs(os.path.dirname(HB), exist_ok=True)
    open(HB, "a").close()
    os.utime(HB, None)
    print("OK")
    return 0


if __name__ == "__main__":
    sys.exit(main())
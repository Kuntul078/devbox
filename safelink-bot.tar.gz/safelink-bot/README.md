# SafelinkU Bypass Bot

Bot Telegram + worker untuk nge-bypass safelink (sfl.gl / SafelinkU) dan
menghitung view ke publisher. Setiap view = device profile baru + IP keluar baru.

## Isi paket

| File | Fungsi |
|---|---|
| `sl_bot.py` | panel Telegram (kirim link -> pilih country & jumlah view -> antrian) |
| `sl_worker.py` | konsumer `queue.txt`, jalanin tiap view, kirim progress ke Telegram |
| `bypass_engine.py` | state machine safelink (Open -> countdown -> Next -> Turnstile -> Go to Link) |
| `fp_spoof.py` | device profile + init script anti-detect (UA/screen/GPU/TZ/font konsisten) |
| `proxy_setup.py` | **konfigurasi proxy manual BrightData** (prompt + CLI + tes) |
| `proxy.env` | kredensial proxy hasil input manual (**0600, JANGAN dibagikan; TIDAK ikut di rar**) |
| `proxy.env.example` | contoh format `proxy.env` |
| `start_worker.sh` | start manual: Xvfb + prompt/cek proxy + panel + worker |
| `canary.py` | pengecekan liveness view (dipakai watchdog) |
| `fp_report.py`, `stealth_audit.py`, `trace_views.py`, `verify_unique.py` | tooling debug fingerprint/uniqueness |
| `debug_flow.py`, `debug_flow2.py` | debug alur safelink |

## Proxy manual BrightData (wajib)

Tidak ada kredensial proxy di dalam kode. Bot baca `proxy.env`, dan kalau belum
ada dia **tidak akan memakai IP server** — worker standby dan kirim notif.

Isi lewat salah satu cara:

1. **Prompt saat start** (paling awal):
   ```
   bash start_worker.sh
   ```
   diminta `proxy>` -> tempel salah satu format:
   ```
   brd-customer-hl_XXXX-zone-isp_proxy1-country-{country}-session-{session}:PASSWORD@brd.superproxy.io:44445
   ```
   atau `host:port:user:pass`.

2. **Dari Telegram** (tanpa SSH):
   ```
   /proxy user:pass@host:port
   /proxy host:port:user:pass
   /proxy country us
   /proxy test
   /proxy off / /proxy on
   ```

2b. **Wizard manual di Telegram** (yang paling gampang — ga perlu ketik panjang):
   ```
   /proxy            -> muncul tombol: 🛠 Input manual / 📋 Paste / 📥 Ambil dari file
   ```
   * **🛠 Input manual** = 5 langkah dipandu: username -> password -> host ->
     port -> country (Enter/`-` = default). Password tidak ditampilkan lagi dan
     pesannya dihapus otomatis; hasilnya disimpan ke `proxy.env` (0600).
   * **📋 Paste 1 baris** = terima `user:pass@host:port`, `host:port:user:pass`,
     `host port user pass`, `user pass host port`.
   * **📥 Ambil dari file** = baca kredensial dari `.env` / `proxy.env` / txt di
     server (dites dulu, lalu tinggal tekan 💾 Simpan).
   * `/cancel` kapan saja buat batal.

3. **CLI**:
   ```
   /usr/bin/python3 proxy_setup.py --line "user:pass@host:port"
   /usr/bin/python3 proxy_setup.py --check
   ```

`{country}` diganti country view, `{session}` diganti id acak **tiap view** supaya
IP keluar selalu beda (IP sama = view di-dedupe, dashboard publisher tidak naik).
`/proxy` reload per view, jadi ganti kredensial langsung kepakai tanpa restart.

## Jalanin

```bash
# start (Xvfb + cek/proxy prompt + panel + worker)
bash /root/safelink-bot/start_worker.sh

# stop
systemctl stop safelink-bot safelink-worker

# log
journalctl -u safelink-worker -f
tail -f /root/safelink-bot/logs/worker.log
```

Pakai: kirim link `https://sfl.gl/XXXX` (atau alias `XXXX`) ke bot ->
atur country / jumlah view -> *Jalankan sekarang*.

## Requirement

* `/usr/bin/python3` + `pip install --break-system-packages playwright requests`
* Playwright chromium headful (`PLAYWRIGHT_BROWSERS_PATH` default `~/.cache/ms-playwright`)
* Xvfb `:99` (unit `safelink-xvfb.service`, 1920x1080x24, butuh `--enable-unsafe-swiftshader`
  kalau tanpa GPU supaya WebGL tidak null)
* Kredensial BrightData (zona ISP/residential) yang mendukung rotasi per session

## Deploy dari rar

```bash
unrar x safelink-bot.rar
cd safelink-bot
pip install --break-system-packages -r requirements.txt
bash start_worker.sh        # akan minta proxy manual BrightData
```
#!/usr/bin/python3
"""
SafelinkU bypass worker.

Consumes queue.txt (one JSON job per line):
    {"url": "https://sfl.gl/PpJU", "views": 5, "country": "id", "done": 0}
Each job runs `views` bypass attempts, every attempt with a fresh device profile
and a fresh residential exit IP, then the job is removed. The current job is
tracked in state.json so the panel can show live progress and so a restart does
not lose the remaining views.
"""
import os, sys, time, json, random, logging, traceback, threading

HERE = os.path.dirname(os.path.abspath(__file__))
QUEUE = os.path.join(HERE, "queue.txt")
STATE = os.path.join(HERE, "state.json")
RESULTS = os.path.join(HERE, "results.txt")
HB = "/home/ubuntu/workspace/projects/safelink-bot/.bot-heartbeat/safelink-worker.hb"
LOGDIR = os.path.join(HERE, "logs")
os.makedirs(LOGDIR, exist_ok=True)
os.makedirs(os.path.dirname(HB), exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s",
    handlers=[logging.FileHandler(os.path.join(LOGDIR, "worker.log")),
              logging.StreamHandler(sys.stdout)])

ENV = {}


def load_env():
    p = os.path.join(HERE, ".env")
    if os.path.exists(p):
        for line in open(p):
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            ENV[k.strip()] = v.strip()
            os.environ[k.strip()] = v.strip()   # overwrite, never setdefault


def tg(method, **payload):
    import requests
    tok = ENV.get("TELEGRAM_BOT_TOKEN")
    if not tok:
        return {}
    try:
        r = requests.post(f"https://api.telegram.org/bot{tok}/{method}",
                          json=payload, timeout=(10, 30))
        return r.json()
    except Exception as e:
        logging.warning("tg %s failed: %s", method, e)
        return {}


def notify(text, chat_id=None):
    cid = chat_id or ENV.get("TELEGRAM_CHAT_ID")
    if cid:
        tg("sendMessage", chat_id=cid, text=text, disable_web_page_preview=True)


def read_lines(path):
    if not os.path.exists(path):
        return []
    return [l.strip() for l in open(path) if l.strip()]


def write_lines(path, items):
    tmp = path + ".tmp"
    with open(tmp, "w") as f:
        for i in items:
            f.write(i + "\n")
    os.replace(tmp, path)


def parse_jobs():
    """Accept new JSON jobs and legacy bare-URL lines (treated as 1 view, default country)."""
    jobs, seen = [], set()
    for ln in read_lines(QUEUE):
        try:
            j = json.loads(ln)
            if isinstance(j, dict) and j.get("url"):
                j.setdefault("views", 1)
                j.setdefault("country", ENV.get("PROXY_COUNTRY", "id"))
                j.setdefault("done", 0)
                key = ln
            else:
                raise ValueError
        except Exception:
            j = {"url": ln, "views": 1, "country": ENV.get("PROXY_COUNTRY", "id"), "done": 0}
            key = json.dumps(j, ensure_ascii=False)
        if key not in seen:
            seen.add(key)
            jobs.append(j)
    return jobs


def write_jobs(jobs):
    write_lines(QUEUE, [json.dumps(j, ensure_ascii=False) for j in jobs])


def set_state(job):
    """Persist the in-flight job. worker_state() in the panel shows a live job only
    while queue.txt is EMPTY (i.e. the worker actually holds it) — clearing the
    queue must not leave a stale 'running' indicator."""
    try:
        if job:
            with open(STATE, "w") as f:
                json.dump(job, f, ensure_ascii=False)
        else:
            with open(STATE, "w") as f:
                f.write("{}")
    except Exception:
        pass


def run_one(url, country):
    sys.path.insert(0, HERE)
    import proxy_setup
    import bypass_engine
    # Reload proxy manual SETIAP view: operator bisa ganti kredensial dari panel
    # Telegram dan view berikutnya langsung pakai proxy baru, tanpa restart.
    cfg = proxy_setup.load()
    if cfg:
        proxy_setup.export_env(cfg)
        if not proxy_setup.configured():
            logging.error("proxy.env ada tapi PROXY_USER/PROXY_PASS kosong — "
                          "view akan lewat IP server (rawan dedupe)")
        else:
            logging.info("proxy aktif: %s (country=%s)",
                         cfg.get("PROXY_HOST"), cfg.get("PROXY_COUNTRY"))
    else:
        logging.error("proxy.env BELUM DISET — view jalan tanpa proxy. "
                      "Set lewat panel: /proxy")
    # proxies.txt (daftar fixed-IP) = sumber proxy utama di box ini: dia menang
    # atas proxy.env, jadi use_proxy harus True walaupun proxy.env kosong.
    _has_list = False
    try:
        _p = os.path.join(HERE, "proxies.txt")
        _has_list = os.path.exists(_p) and os.path.getsize(_p) > 0
    except Exception:
        pass
    use_proxy = _has_list or (
        bool(cfg) and str(cfg.get("USE_PROXY", "1")).lower() not in ("0", "false", ""))
    # hard cap per view: MUST stay below the watchdog STALE_SEC (400) so a
    # healthy worker is never restarted mid-view, while a truly hung browser is.
    hard = int(ENV.get("VIEW_TIMEOUT", 300))
    prog = os.path.join(HERE, ".progress")

    def bump_progress():
        """Progress must advance per ATTEMPT, not per view: a single view can sit
        for 200-300s and looks identical to a hang to any external observer."""
        try:
            open(prog, "a").close()
            os.utime(prog, None)
        except Exception:
            pass

    return bypass_engine.bypass_with_retry(
        url, attempts=int(ENV.get("ATTEMPTS", 3)), country=country,
        use_proxy=use_proxy, headless=False, shot_prefix="live",
        solvegate_key=ENV.get("SOLVEGATE_API_KEY"), hard_timeout=hard,
        on_attempt=bump_progress)


def prune_profiles(max_age=86400, keep=40):
    """One throwaway browser profile per view; without pruning they accumulate
    forever (42 dirs / 44 X clients already) and every chromium start nibbles at
    the same X connection table."""
    import shutil, glob
    now = time.time()
    dirs = []
    for d in glob.glob(os.path.join(HERE, ".profiles", "*")):
        try:
            dirs.append((os.path.getmtime(d), d))
        except Exception:
            pass
    dirs.sort(reverse=True)
    for i, (mtime, d) in enumerate(dirs):
        if i >= keep or (now - mtime) > max_age:
            shutil.rmtree(d, ignore_errors=True)
    return len(dirs) - min(len(dirs), keep)


def hb_thread():
    """Heartbeat MUST come from its own thread, not from the loop top.

    A working view legitimately runs 200-300s and up to ATTEMPTS of them; a loop-top
    heartbeat therefore goes stale mid-view and the watchdog restarts a perfectly
    healthy worker (observed: hb 411s while a view was mid-flight). With the
    heartbeat owned by a thread, it measures "process alive"; real stalls are caught
    by the canary via .progress (touched at every attempt)."""
    while True:
        try:
            open(HB, "a").close()
            os.utime(HB, None)
        except Exception:
            pass
        time.sleep(30)


def alarm_thread():
    """Separate liveness reporter (never touches the heartbeat, so it cannot mask
    a hung worker): shouts in Telegram when a job sits without progress."""
    prog = os.path.join(HERE, ".progress")
    limit = 900
    last_alert = [0.0]

    def loop():
        while True:
            time.sleep(60)
            try:
                st = json.load(open(STATE))
            except Exception:
                st = {}
            if not st.get("url"):
                continue
            try:
                age = time.time() - os.path.getmtime(prog)
            except Exception:
                age = 9999
            if age > limit and time.time() - last_alert[0] > 900:
                last_alert[0] = time.time()
                notify(f"🚨 Worker macet {int(age/60)} menit tanpa progress\n"
                       f"🔗 {st.get('url')}\n"
                       f"Lihat: journalctl -u safelink-worker -n 50")

    threading.Thread(target=loop, daemon=True).start()


def requeue_inflight():
    """A restart mid-job used to LOSE the remaining views: the worker only reads
    queue.txt, so a job parked in state.json vanished while the panel kept
    showing it as 'Sedang jalan' forever. Re-enqueue it on startup."""
    try:
        st = json.load(open(STATE))
    except Exception:
        return
    if not st.get("url"):
        return
    done, views = int(st.get("done", 0)), int(st.get("views", 1))
    if done < views:
        jobs = parse_jobs()
        if not any(j.get("url") == st["url"] for j in jobs):
            jobs.insert(0, {"url": st["url"], "views": views,
                            "country": st.get("country") or ENV.get("PROXY_COUNTRY", "id"),
                            "done": done})
            write_jobs(jobs)
            logging.info("requeued in-flight job after restart: %s (%d view left)",
                         st["url"], views - done)
    set_state({})


def main():
    load_env()
    os.chdir(HERE)
    logging.info("worker start (queue=%s)", QUEUE)
    requeue_inflight()
    threading.Thread(target=prune_profiles, daemon=True).start()
    threading.Thread(target=hb_thread, daemon=True).start()
    alarm_thread()
    prog = os.path.join(HERE, ".progress")
    warned = [0.0]
    while True:
        try:
            # --- GATE PROXY MANUAL -------------------------------------------
            # Kalau proxy.env belum diisi, JANGAN buang view lewat IP server:
            # biarkan job di antrian, tidur, dan ingatkan operator (maks 1x / 10 menit).
            import proxy_setup
            cfg = proxy_setup.load()
            # proxies.txt (daftar kredensial fixed-IP) juga dianggap proxy siap;
            # tanpa cek ini worker standby walaupun daftarnya ada.
            _has_list = False
            try:
                _p = os.path.join(HERE, "proxies.txt")
                _has_list = os.path.exists(_p) and os.path.getsize(_p) > 0
            except Exception:
                pass
            if not proxy_setup.configured() and not _has_list:
                if time.time() - warned[0] > 600:
                    warned[0] = time.time()
                    logging.error("proxy.env belum diset — worker standby, antrian "
                                  "tidak disentuh. Set lewat panel Telegram: /proxy")
                    notify("🔌 *Proxy belum diset* — worker standby.\n"
                           "Buka panel → *🛠 Input manual* (step-by-step), "
                           "atau kirim `/proxy` buat pilih cara input.\n"
                           "Antrian aman, view tidak jalan lewat IP server.")
                time.sleep(30)
                continue
            proxy_setup.export_env(cfg)
            jobs = parse_jobs()
            if not jobs:
                time.sleep(4)
                continue
            job = jobs[0]
            url = job["url"]
            total = int(job.get("views", 1) or 1)
            country = job.get("country") or ENV.get("PROXY_COUNTRY", "id")

            # Claim the job: persist it, and keep ONLY the remaining jobs in queue.txt
            set_state(job)
            write_jobs(jobs[1:])
            try:
                open(prog, "a").close()
                os.utime(prog, None)
            except Exception:
                pass
            idx = int(job.get("done", 0)) + 1
            logging.info("view %d/%d  url=%s country=%s", idx, total, url, country)
            notify(f"⏳ View {idx}/{total} · {country.upper()}\n🔗 {url}")
            try:
                r = run_one(url, country)
            except Exception as e:
                logging.error("engine crash: %s\n%s", e, traceback.format_exc()[-800:])
                r = {"input": url, "final": None, "ok": False,
                     "error": f"engine crash: {e}", "hops": []}
            finally:
                # never let a crashed view leak a chromium tree into the next one.
                # Scoped ke turunan proses worker ini — JANGAN pkill by-name:
                # itu membunuh chromium milik tugas lain di box yang sama.
                try:
                    import scoped_cleanup
                    n, left = scoped_cleanup.kill_own_chromium()
                    if n:
                        logging.info("scoped cleanup: killed=%d sisa=%d", n, left)
                except Exception as e:
                    logging.warning("scoped cleanup gagal: %s", e)

            final = r.get("final") or ""
            clicks = [h for h in r.get("hops", []) if str(h).startswith("click:")]
            with open(RESULTS, "a") as f:
                f.write(json.dumps({
                    "ts": int(time.time()), "input": url, "ok": bool(r.get("ok")),
                    "final": final, "clicks": len(clicks), "hops": r.get("hops", []),
                    "error": r.get("error"), "attempt": r.get("attempt"),
                    "proxy": r.get("proxy_user"), "device": r.get("device"),
                    "country": country, "view": idx, "views": total,
                }, ensure_ascii=False) + "\n")

            dev = r.get("device") or {}
            if r.get("ok") and final:
                notify(f"✅ View {idx}/{total} BERHASIL\n🔗 {url}\n"
                       f"🎯 {final}\n"
                       f"🖱️ {len(clicks)} klik iklan\n"
                       f"🌐 {country.upper()} · session "
                       f"{(r.get('proxy_user') or '-')[-10:]} (attempt {r.get('attempt')})\n"
                       f"📱 {dev.get('platform','?')} · {dev.get('screen')} · {dev.get('tz','?')}")
            else:
                notify(f"⚠️ View {idx}/{total} GAGAL\n🔗 {url}\n"
                       f"Alasan: {r.get('error') or 'tidak terdeteksi tujuan'}")

            # remaining views of this same job go back to the FRONT of the queue
            if idx < total:
                job["done"] = idx
                jobs = parse_jobs()
                write_jobs([job] + jobs)
            else:
                set_state({})
                notify(f"🏁 Selesai: {total} view untuk {url}")

            d = random.uniform(float(ENV.get("DELAY_MIN", 8)), float(ENV.get("DELAY_MAX", 20)))
            logging.info("sleep %.1fs", d)
            time.sleep(d)
        except Exception as e:
            logging.error("worker loop error: %s\n%s", e, traceback.format_exc()[-600:])
            time.sleep(5)


if __name__ == "__main__":
    main()
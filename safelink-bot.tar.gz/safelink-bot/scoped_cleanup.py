#!/usr/bin/python3
"""
Scoped chromium cleanup for safelink-bot.

Masalah yang diganti
--------------------
`os.system("pkill -f 'chrome-linux64/chrome'")` (dulu dipanggil di
bypass_engine.bypass_guarded() dan sl_worker.main() setiap selesai view)
mencocokkan SEMUA proses chromium di mesin — termasuk milik tugas lain yang
jalan bersamaan di box yang sama. Kill-by-name = damage ke pekerjaan orang lain.

Aturan di box ini: cleanup harus di-scope ke proses yang KITA sendiri luncurkan.

Cara kerja
----------
Chromium selalu di-spawn sebagai turunan (descendant) dari proses Python ini
(playwright in-process). Jadi: telusuri /proc, ambil semua descendant dari
os.getpid(), dan kill HANYA yang cmdline-nya chromium. Proses chromium milik
script lain bukan turunan kita, jadi tidak pernah kesentuh.
"""

import os
import signal
import time

CHROME_MARKERS = (b"chrome-linux64/chrome", b"chrome-linux/chrome",
                  b"chrome-headless-shell", b"chromium")


def _ppid(pid):
    try:
        with open("/proc/%d/stat" % pid) as fh:
            return int(fh.read().rsplit(") ", 1)[1].split()[1])
    except (OSError, IndexError, ValueError):
        return 0


def descendants(root=None):
    """Semua PID turunan (rekursif) dari `root` (default: proses ini)."""
    root = os.getpid() if root is None else root
    out, stack = [], [root]
    try:
        entries = [int(e) for e in os.listdir("/proc") if e.isdigit()]
    except OSError:
        return out
    kids = {}
    for pid in entries:
        kids.setdefault(_ppid(pid), []).append(pid)
    while stack:
        cur = stack.pop()
        for pid in kids.get(cur, []):
            out.append(pid)
            stack.append(pid)
    return out


def _cmdline(pid):
    try:
        with open("/proc/%d/cmdline" % pid, "rb") as fh:
            return fh.read()
    except OSError:
        return b""


def _is_chrome(pid):
    c = _cmdline(pid)
    return bool(c) and any(m in c for m in CHROME_MARKERS)


def kill_own_chromium(root=None, wait_s=10.0):
    """Kill chromium yang merupakan turunan kita sendiri. -> (jumlah, sisa).

    Tidak pernah menyentuh proses milik script/tugas lain.
    """
    root = os.getpid() if root is None else root
    victims = [d for d in descendants(root) if _is_chrome(d)]
    # bunuh dari daun ke akar supaya parent tidak sempat re-spawn anak
    for pid in reversed(victims):
        try:
            os.kill(pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        except PermissionError:
            pass
    deadline = time.time() + wait_s
    while time.time() < deadline:
        left = [d for d in descendants(root) if _is_chrome(d)]
        if not left:
            return len(victims), 0
        time.sleep(0.3)
    left = [d for d in descendants(root) if _is_chrome(d)]
    return len(victims), len(left)


def alive_own_chromium(root=None):
    root = os.getpid() if root is None else root
    return [d for d in descendants(root) if _is_chrome(d)]


if __name__ == "__main__":
    n, left = kill_own_chromium()
    print("killed=%d sisa=%d" % (n, left))
